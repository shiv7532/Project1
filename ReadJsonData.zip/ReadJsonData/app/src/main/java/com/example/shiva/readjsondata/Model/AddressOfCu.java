package com.example.shiva.readjsondata.Model;

public class AddressOfCu {

     String street;
     String suite;
     String city;
    String zipcode;
     Geo geo;


    public AddressOfCu(String street, String suite, String city,String zipcode, Geo geo) {
        this.street = street;
        this.suite = suite;
        this.city = city;
        this.zipcode = zipcode;
        this.geo= geo;
    }

    public String getStreet() {
        return street;
    }

    public String getSuite() {
        return suite;
    }

    public String getCity() {
        return city;
    }

    public String getZipcode() {
        return zipcode;
    }

    public Geo getGeo() {
        return geo;
    }
}


