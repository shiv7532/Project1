package com.example.shiva.readjsondata.Retrofit;

import com.example.shiva.readjsondata.Model.Details;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface DataAPI {

    //DataApi is an interface which defines the http operations

    @GET("users")//this method is used to get a response from server
    Call<List<Details>> getDetails();




}
