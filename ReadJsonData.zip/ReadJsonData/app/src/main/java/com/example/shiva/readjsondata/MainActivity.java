package com.example.shiva.readjsondata;

import android.content.Context;
import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.shiva.readjsondata.Model.AddressOfCu;
import com.example.shiva.readjsondata.Model.Details;
import com.example.shiva.readjsondata.Retrofit.RetrofitClient;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    private static final String TAG = "MainActivity";
    private ArrayList<String> Name = new ArrayList<>();
    private ArrayList<String> UserEmail = new ArrayList<>();
    private ArrayList<String> UserName = new ArrayList<>();
    private ArrayList<String> street = new ArrayList<>();
    private  ArrayList<String> City = new ArrayList<>();

    private ArrayList<String> Suite = new ArrayList<>();
    private ArrayList<String> ZipCode = new ArrayList<>();
    private ArrayList<String> Latitude = new ArrayList<>();
    private ArrayList<String> Longitude = new ArrayList<>();
    private ArrayList<String> CompName = new ArrayList<>();
    private ArrayList<String> CompCatch = new ArrayList<>();
    private ArrayList<String> CompBs = new ArrayList<>();
    private ArrayList<String> UserPhone  = new ArrayList<>();
    private ArrayList<String> Website = new ArrayList<>();

    List<Details> userdata;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView_id);
        Log.e(TAG,"Oncreate is called");


        Call<List<Details>> call = RetrofitClient.getInstance().getApi().getDetails();
        call.enqueue(new Callback<List<Details>>() {
            @Override
            public void onResponse(Call<List<Details>> call, Response<List<Details>> response) {


                if(response.isSuccessful())
                {
                    userdata=response.body();

                    for(int i=0; i<userdata.size(); i++)
                    {
                        String sName = userdata.get(i).getName();
                        String sEmail = userdata.get(i).getEmail();
                        String SUsername = userdata.get(i).getUsername();
                        String SStreet = userdata.get(i).getAddress().getStreet();
                        String Ssuite = userdata.get(i).getAddress().getSuite();
                        String SZipcode = userdata.get(i).getAddress().getZipcode();
                        String Swebsite = userdata.get(i).getWebsite();
                        String SCity = userdata.get(i).getAddress().getCity();
                        String SCname = userdata.get(i).getCompany().getName();
                        String SCcatch = userdata.get(i).getCompany().getCatchPhrase();
                        String Sbs = userdata.get(i).getCompany().getBs();
                        String Sphone = userdata.get(i).getPhone();
                        String Slat = userdata.get(i).getAddress().getGeo().getLat();
                        String Slng = userdata.get(i).getAddress().getGeo().getLng();

                        Toast.makeText(MainActivity.this, sName + " " + sEmail, Toast.LENGTH_SHORT).show();
                         Log.e(TAG,""+sName+sEmail+SUsername+SStreet+Ssuite+SZipcode+Swebsite+SCity+SCname+SCcatch+Sbs+Sphone+Slat+Slng);


                        Name.add(sName);
                        UserEmail.add(sEmail);
                        UserName.add(SUsername);
                        street.add(SStreet);
                        Suite.add(Ssuite);
                        ZipCode.add(SZipcode);
                        Website.add(Swebsite);
                        City.add(SCity);
                        CompName.add(SCname);
                        CompCatch.add(SCcatch);
                        CompBs.add(Sbs);
                        UserPhone.add(Sphone);
                        Latitude.add(Slat);
                        Longitude.add(Slng);

                    }

                    RecyclerViewAdapter recyclerViewAdapter = new RecyclerViewAdapter(MainActivity.this, Name,UserEmail,UserName,street,Suite,ZipCode,Latitude,Longitude,Website,City
                    ,CompName,CompCatch,CompBs,UserPhone);
                    recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                    recyclerView.setHasFixedSize(true);
                    recyclerView.setAdapter(recyclerViewAdapter);
                }
                else {
                    Toast.makeText(MainActivity.this,"response is not successful",Toast.LENGTH_SHORT).show();
                }


            }

            @Override
            public void onFailure(Call<List<Details>> call, Throwable t) {

                Toast.makeText(MainActivity.this,"do not get response",Toast.LENGTH_SHORT).show();

            }
        });

    }


}
