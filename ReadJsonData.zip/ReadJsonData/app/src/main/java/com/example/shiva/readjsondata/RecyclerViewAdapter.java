package com.example.shiva.readjsondata;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    ArrayList<String> Uname = new ArrayList<String>();
    ArrayList<String> Email =new ArrayList<String>();
    ArrayList<String> gUserName = new ArrayList<>();
   ArrayList<String> Street = new ArrayList<>();
     ArrayList<String> Suite = new ArrayList<>();
     ArrayList<String> Zipcode = new ArrayList<>();
     ArrayList<String> Lati = new ArrayList<>();
    ArrayList<String> Longi = new ArrayList<>();
     ArrayList<String> Website = new ArrayList<>();
     ArrayList<String> City = new ArrayList<>();
     ArrayList<String> CompName = new ArrayList<>();
     ArrayList<String> CompCatch = new ArrayList<>();
     ArrayList<String> Combs = new ArrayList<>();
     ArrayList<String> Userphoen= new ArrayList<>();

    Context mcontext;


    public RecyclerViewAdapter(Context context, ArrayList<String> name, ArrayList<String> email, ArrayList<String> uname, ArrayList<String> street,
                               ArrayList<String> suite, ArrayList<String> zipCode, ArrayList<String> Lati,ArrayList<String> longi,
                               ArrayList<String> website, ArrayList<String> city,
                               ArrayList<String> compName, ArrayList<String> compCatch, ArrayList<String> compbs,ArrayList<String > userphone)
    {
        this.mcontext = context;
       this.Uname = name;
        this.Email = email;
        this.gUserName= uname;
        this.Street=street;
        this.Suite=suite;
        this.Zipcode= zipCode;
        this.Lati=Lati;
        this.Longi= longi;
        this.Website= website;
        this.City = city;
        this.CompName = compName;
        this.CompCatch = compCatch;
        this.Combs = compbs;
        this.Userphoen= userphone;


    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // This method create the object of ViewHolder class and return the object
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview,parent,false);
        ViewHolder mholder= new ViewHolder(view);
        return mholder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.nameTextView.setText(Uname.get(position));
        holder.emailTextView.setText(Email.get(position));
        holder.unameText.setText(gUserName.get(position));
        holder.streetTextView.setText(Street.get(position));
        holder.suiteTextView.setText(Suite.get(position));
        holder.zipcodeTextView.setText(Zipcode.get(position));
        holder.latTextView.setText(Lati.get(position));
        holder.LongTextView.setText(Longi.get(position));
        holder.webstieTextView.setText(Website.get(position));
        holder.compnameTextView.setText(CompName.get(position));
        holder.combCatchTextView.setText(CompCatch.get(position));
        holder.cobsTextView.setText(Combs.get(position));
        holder.phoneTextView.setText(Userphoen.get(position));

    }

    @Override
    public int getItemCount() {
        return Uname.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView nameTextView,emailTextView,unameText,streetTextView,suiteTextView,cityTextView,zipcodeTextView,latTextView,LongTextView,phoneTextView;
        TextView webstieTextView,compnameTextView,cobsTextView,combCatchTextView;
        CircleImageView circleImageView;
        CardView parentLayout;


        public ViewHolder(View itemView) {
            super(itemView);
            nameTextView= itemView.findViewById(R.id.name_id);
            emailTextView= itemView.findViewById(R.id.email_id);
            unameText=itemView.findViewById(R.id.username_id);
            streetTextView = itemView.findViewById(R.id.street_id);
            suiteTextView = itemView.findViewById(R.id.street_id);
            cityTextView   = itemView.findViewById(R.id.city_id);
            zipcodeTextView = itemView.findViewById(R.id.zipcode_id);
            latTextView = itemView.findViewById(R.id.lat_id);
            LongTextView = itemView.findViewById(R.id.long_id);
            phoneTextView = itemView.findViewById(R.id.phoneNo_id);
            webstieTextView= itemView.findViewById(R.id.website_id);
            compnameTextView = itemView.findViewById(R.id.C_name_id);
            cobsTextView = itemView.findViewById(R.id.C_bs_id);
            circleImageView = itemView.findViewById(R.id.image_id);
            parentLayout = itemView.findViewById(R.id.parent_layout);
            combCatchTextView = itemView.findViewById(R.id.C_catchphrase_id);


        }
    }
}
